require "#{File.dirname(__FILE__)}/helper.rb"

class OperatorTest < Test::Unit::TestCase

  describe "Comparable" do

    class Ray

      def initialize(x,y)
        @x, @y = x, y
      end

      attr_reader :x,:y

      def angle
        Math.atan2(y,x)
      end
      
      include Comparable

       # NOTE: IMPLEMENT THIS (using angle)
       def <=>(other)
         #  returns 0 when the two are equal, 
         #  1 when the current object is greater than the other
         # -1 when the current object is lesser than the other
         #  and nil when comparison cannot be made
       end

    end

    test "should provide a meaningful == and !=" do
      flunk "You need to implement Ray#<=>"

      ray1 = Ray.new(2,2)
      ray2 = Ray.new(4,4)

      ray3 = Ray.new(2,3)
      ray4 = Ray.new(4,6)

      assert ray1 == ray2
      assert ray3 == ray4

      assert ray2 != ray3
    end

    _test "should provide a meaningful <, <=, >, >=" do
      ray1 = Ray.new(1,4)
      ray2 = Ray.new(1,2)
      
      assert ray1 >= ray1
      assert ray1 >= ray2

      assert ray2 <= ray1
      assert ray2 <= ray2

      assert ray1 > ray2
      assert !(ray1 > ray1)

      assert ray2 < ray1
      assert !(ray2 < ray2)
    end

    _test "should provide a between? method" do
      ray1 = Ray.new(1,2)
      ray2 = Ray.new(1,4)
      ray3 = Ray.new(1,3)

      assert ray3.between?(ray1, ray2)

      assert ! ray2.between?(ray1, ray3)

      # order matters in between?
      assert ! ray3.between?(ray2, ray1)
    end

  end

  describe "Custom Operators" do
  
    _test "operators in Ruby are just method calls" do
      assert_equal __, 2.+(2)
      assert_equal __, [1,2,3].<<(4)
    end

    class Vector
     
      include Enumerable

      def initialize(*arr)
        @data = arr
      end

      def each
        @data.each { |e| yield(e) }
      end

      def ==(other)
        @data.to_a == other.to_a
      end

      def length
        @data.length
      end

      def +(other)
        # NOTE: implement this
      end

    end

    _test "Vector#+" do
      v1 = Vector.new(4,8,10)
      v2 = Vector.new(2,1,9)

      assert_equal Vector.new(6,9,19), v1 + v2
    end

    _test "Defining + also gets you +=" do
      v1 = Vector.new(4,8,10)
      v1 += Vector.new(5,0,3)

      assert_equal Vector.new(9,8,13), v1
    end

  end



end


