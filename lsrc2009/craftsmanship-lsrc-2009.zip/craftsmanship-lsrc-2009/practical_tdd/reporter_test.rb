require "test/unit"
require "rubygems"
require "contest"
require "nokogiri"
require "faker"

class ReporterTest < Test::Unit::TestCase

  setup do
    @report_data = (1..15).map do
      [ "#{Faker::Name.first_name} #{Faker::Name.last_name}", 
        rand(40), rand(40) ]
    end

    @start_date = Date.today
    @end_date   = Date.today + 13
    @reporter = Reporter.new(@start_date, @end_date, @report_data)
  end

  test "report header" do
    output = @reporter.render 
    start_date_formatted = @start_date.strftime("%Y.%m.%d")
    end_date_formatted   = @end_date.strftime("%Y.%m.%d")

    assert_equal(
      "Time Report: (#{start_date_formatted} - #{end_date_formatted})", 
      Nokogiri::HTML(output).at("//h2").content 
    )
  end

  test "report headers" do
    output = @reporter.render

    data = Nokogiri::HTML(output).xpath("//tr/th").map do |e|
      e.content
    end

    assert_equal ["Employee", "Week 1", "Week 2", "Total Hours"], data
  end

  test "all data should be present in HTML table" do
    output = @reporter.render

    data = Nokogiri::HTML(output).xpath('//tr').map do |row|
      next unless row.at("td")
      [ row.at('td[@class="employee"]').content.strip,
        row.at('td[@class="wk1_record"]').content.strip.to_i,
        row.at('td[@class="wk2_record"]').content.strip.to_i ]
    end.compact

    assert_equal @report_data, data
  end

  test "total hours should equal wk1 hrs + wk2 hours" do
    output = @reporter.render

    Nokogiri::HTML(output).xpath('//tr').each do |row|
      @block_executed = true
      next unless row.at("td")

      wk1 = row.at('td[@class="wk1_record"]').content.to_i
      wk2 = row.at('td[@class="wk2_record"]').content.to_i

      assert_equal wk1+wk2, row.at('td[@class="total_hours"]').content.to_i
    end

    assert @block_executed, "Block should have executed, but didn't"


  end

end