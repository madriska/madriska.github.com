$reload_count += 1

$reload_app.get('/') { 'Hello from reload file' }
